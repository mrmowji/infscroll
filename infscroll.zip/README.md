# Infscroll!

### A Chrome extension for scrolling a lazy-loading content on any website.

It's a fork of [Oles Bolotniuk's ScrollIt](https://github.com/always-oles/ScrollIt).